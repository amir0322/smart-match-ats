import os

UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER", "uploads")
MAX_CONTENT_LENGTH = int(os.getenv("MAX_CONTENT_LENGTH", 5 * 1024 * 1024))
SECRET_KEY = os.getenv("SECRET_KEY", "default-secret-key-change-in-production")
