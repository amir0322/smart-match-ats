import os

import spacy
from docx import Document
from pdfminer.high_level import extract_text as pdf_extract_text
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

SKILLS_LIST = [
    "python",
    "sql",
    "machine learning",
    "flask",
    "pandas",
    "numpy",
    "scikit-learn",
    "tensorflow",
    "docker",
    "aws",
    "nlp",
    "deep learning",
    "java",
    "react",
    "node.js",
    "git",
    "data analysis",
    "tableau",
    "power bi",
    "excel",
    "r",
    "spark",
    "kafka",
    "airflow",
]

_NLP = None


def _get_nlp_model():
    global _NLP
    if _NLP is None:
        _NLP = spacy.load("en_core_web_sm")
    return _NLP


def extract_text_from_pdf(filepath):
    return pdf_extract_text(filepath) or ""


def extract_text_from_docx(filepath):
    document = Document(filepath)
    return "\n".join(paragraph.text for paragraph in document.paragraphs).strip()


def extract_text(filepath):
    extension = os.path.splitext(filepath)[1].lower()
    if extension == ".pdf":
        return extract_text_from_pdf(filepath)
    if extension == ".docx":
        return extract_text_from_docx(filepath)
    raise ValueError("Unsupported file format. Please upload PDF or DOCX files only.")


def extract_skills(text):
    if not text:
        return []

    lowered_text = text.lower()
    nlp = _get_nlp_model()
    doc = nlp(lowered_text)

    candidates = set()
    for chunk in doc.noun_chunks:
        chunk_text = chunk.text.strip().lower()
        if chunk_text:
            candidates.add(chunk_text)

    for entity in doc.ents:
        entity_text = entity.text.strip().lower()
        if entity_text:
            candidates.add(entity_text)

    matched_skills = set()
    for skill in SKILLS_LIST:
        normalized_skill = skill.lower()
        if normalized_skill in lowered_text:
            matched_skills.add(normalized_skill)
            continue

        if any(normalized_skill == candidate or normalized_skill in candidate for candidate in candidates):
            matched_skills.add(normalized_skill)

    return sorted(matched_skills)


def compute_match_score(cv_skills, job_skills):
    cv_normalized = sorted({skill.strip().lower() for skill in cv_skills if skill and skill.strip()})
    job_normalized = sorted({skill.strip().lower() for skill in job_skills if skill and skill.strip()})

    matched_skills = sorted(set(cv_normalized).intersection(job_normalized))
    missing_skills = sorted(set(job_normalized).difference(cv_normalized))

    if not cv_normalized or not job_normalized:
        return 0.0, matched_skills, missing_skills

    cv_text = " ".join(cv_normalized)
    job_text = " ".join(job_normalized)

    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform([cv_text, job_text])
    similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]

    score = max(0.0, min(100.0, similarity * 100.0))
    return round(float(score), 2), matched_skills, missing_skills
