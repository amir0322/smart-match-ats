import os
import uuid

from flask import (
    Blueprint,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)

from .nlp_engine import compute_match_score, extract_skills, extract_text

main = Blueprint("main", __name__)
ALLOWED_EXTENSIONS = {".pdf", ".docx"}


def _is_allowed_file(filename):
    extension = os.path.splitext(filename)[1].lower()
    return extension in ALLOWED_EXTENSIONS


@main.route("/", methods=["GET"])
def index():
    try:
        return render_template("index.html")
    except Exception:
        flash("Unable to load the homepage right now. Please try again.", "error")
        return "", 500


@main.route("/analyze", methods=["GET", "POST"])
def analyze():
    if request.method == "GET":
        flash("Please use the upload form to analyze your CV.", "error")
        return redirect(url_for("main.index"))

    saved_filepath = None
    try:
        uploaded_file = request.files.get("cv_file")
        job_description = request.form.get("job_description", "").strip()

        if not uploaded_file or not uploaded_file.filename:
            flash("Please upload a CV file in PDF or DOCX format.", "error")
            return redirect(url_for("main.index"))

        if not _is_allowed_file(uploaded_file.filename):
            flash("Invalid file type. Only PDF and DOCX files are allowed.", "error")
            return redirect(url_for("main.index"))

        if not job_description:
            flash("Please paste a job description before analyzing.", "error")
            return redirect(url_for("main.index"))

        extension = os.path.splitext(uploaded_file.filename)[1].lower()
        unique_filename = f"{uuid.uuid4().hex}{extension}"
        saved_filepath = os.path.join(current_app.config["UPLOAD_FOLDER"], unique_filename)
        uploaded_file.save(saved_filepath)

        cv_text = extract_text(saved_filepath)
        cv_skills = extract_skills(cv_text)
        job_skills = extract_skills(job_description)

        score, matched_skills, missing_skills = compute_match_score(cv_skills, job_skills)

        session["score"] = score
        session["cv_skills"] = cv_skills
        session["matched_skills"] = matched_skills
        session["missing_skills"] = missing_skills

        flash("Analysis completed successfully.", "success")
        return redirect(url_for("main.result"))
    except ValueError as exc:
        flash(str(exc), "error")
        return redirect(url_for("main.index"))
    except Exception:
        flash("Something went wrong during analysis. Please try again.", "error")
        return redirect(url_for("main.index"))
    finally:
        if saved_filepath and os.path.exists(saved_filepath):
            try:
                os.remove(saved_filepath)
            except OSError:
                pass


@main.route("/result", methods=["GET"])
def result():
    try:
        score = session.get("score")
        if score is None:
            flash("No analysis result found. Please upload a CV to begin.", "error")
            return redirect(url_for("main.index"))

        return render_template(
            "result.html",
            score=score,
            cv_skills=session.get("cv_skills", []),
            matched_skills=session.get("matched_skills", []),
            missing_skills=session.get("missing_skills", []),
        )
    except Exception:
        flash("Unable to load results at the moment. Please try again.", "error")
        return redirect(url_for("main.index"))


@main.route("/reset", methods=["GET"])
def reset():
    try:
        session.clear()
        flash("Session cleared. You can analyze another CV.", "success")
        return redirect(url_for("main.index"))
    except Exception:
        flash("Unable to reset the session right now. Please try again.", "error")
        return redirect(url_for("main.index"))
