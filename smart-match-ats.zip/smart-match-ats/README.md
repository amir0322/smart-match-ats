# Smart Match ATS

**Tagline:** NLP-powered CV-to-Job-Description matching tool built with Flask and spaCy

## Overview
Smart Match ATS helps candidates quickly evaluate how well their CV aligns with a target job description. It extracts text from PDF and DOCX resumes, identifies relevant skills using NLP, and computes a match score using cosine similarity. The app presents a clear results dashboard with matched and missing skills to guide CV improvements.

## Features
- PDF and DOCX CV parsing
- Skill extraction via spaCy NLP
- Cosine similarity scoring with TF-IDF
- Matched and missing skills breakdown
- Clean Flask web UI with Bootstrap 5

## Tech Stack
- Flask
- spaCy (`en_core_web_sm`)
- pdfminer.six
- python-docx
- scikit-learn
- Bootstrap 5

## How It Works
1. Upload CV
2. NLP Extraction
3. Match Score

## Installation

### Prerequisites
- Python 3.8+
- pip

### Setup & Run

1. **Clone the repository:**
```bash
git clone https://github.com/yourusername/smart-match-ats.git
cd smart-match-ats
```

2. **Create a virtual environment:**
```bash
# On Windows
python -m venv .venv
.venv\Scripts\activate

# On macOS/Linux
python3 -m venv .venv
source .venv/bin/activate
```

3. **Install dependencies:**
```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm
```

4. **Set up environment variables:**
```bash
# Copy the example environment file
cp .env.example .env

# Edit .env and set your SECRET_KEY
# For production, generate a strong secret key
```

5. **Run the application:**
```bash
python run.py
```

Open your browser at: `http://localhost:5000`

## Project Structure
```text
smart-match-ats/
├── app/
│   ├── __init__.py
│   ├── routes.py
│   ├── nlp_engine.py
│   └── templates/
│       ├── base.html
│       ├── index.html
│       └── result.html
├── uploads/          (created at runtime)
├── requirements.txt
├── config.py
├── run.py
├── .gitignore
├── .env.example
└── README.md
```

## Environment Variables

- `SECRET_KEY`: Flask secret key (required for production)
- `FLASK_ENV`: Set to "production" for production deployments
- `DEBUG`: Set to "False" for production
- `UPLOAD_FOLDER`: Directory for temporary file uploads (default: uploads/)
- `MAX_CONTENT_LENGTH`: Maximum file size in bytes (default: 5MB)

## Deployment

### Deploying to Heroku

1. Install Heroku CLI
2. Create a Procfile in the root directory:
```
web: gunicorn run:app
```

3. Deploy:
```bash
heroku login
heroku create your-app-name
git push heroku main
heroku config:set SECRET_KEY=your-production-secret-key
```

### Deploying to PythonAnywhere

1. Create an account on PythonAnywhere
2. Upload your code
3. Create a virtual environment in PythonAnywhere
4. Configure a WSGI file pointing to your Flask app
5. Set environment variables in the Web tab

### Deploying to AWS/Azure/GCP

Follow your cloud provider's documentation for deploying Flask applications.

## Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Author

Amir | BSDS Student | GitHub: amir0322


## Overview
Smart Match ATS helps job seekers quickly evaluate how well their CV aligns with a job description. Users upload a CV (PDF or DOCX), paste a job description, and receive an instant match score with matched and missing skill insights. The project combines NLP-driven skill extraction with similarity scoring in a clean Flask web interface.

## Features
- PDF and DOCX CV text parsing
- Skill extraction via spaCy NLP
- Cosine similarity scoring using TF-IDF
- Matched vs missing skills breakdown
- Clean, responsive Flask web UI

## Tech Stack
- Flask
- spaCy (`en_core_web_sm`)
- pdfminer.six
- python-docx
- scikit-learn
- Bootstrap 5

## How It Works
1. Upload CV
2. NLP Extraction
3. Match Score

## Setup & Run
```bash
pip install flask pdfminer.six python-docx spacy scikit-learn pandas numpy
python -m spacy download en_core_web_sm
python run.py
```

Then open:

```text
http://localhost:5000
```

## Project Structure
```text
smart-match-ats/
├── app/
│   ├── __init__.py
│   ├── routes.py
│   ├── nlp_engine.py
│   └── templates/
│       ├── base.html
│       ├── index.html
│       └── result.html
├── uploads/
├── requirements.txt
├── config.py
└── run.py
```

## Screenshots
Add screenshots here

## Author
Amir | BSDS Student | GitHub: amir0322
