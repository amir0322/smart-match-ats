import os

from dotenv import load_dotenv

from app import create_app

# Load environment variables from .env file
load_dotenv()

app = create_app()


if __name__ == "__main__":
    debug_mode = os.getenv("DEBUG", "False").lower() == "true"
    app.run(debug=debug_mode, port=5000)
